#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main()
{

   /* int x = 2345;

    char strNumero[10];

    sprintf(strNumero, "%d", x);

    puts(strNumero);*/

   // char num[15] = "124578";
   // int x;

  //  x = atoi(num);



   // printf("%d\n",

  printf("%d\n\n", isspace(' '));



    return 0;
}




























