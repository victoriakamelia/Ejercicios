#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
   char cadena[20] = {"Juana"};
   char cadena2[20] = {"Molina"};

   int largo;

    strcat(cadena, " ");
    strcat(cadena, cadena2);
   //printf("%d\n\n", stricmp(cadena2, cadena));

   // printf("%s\n", cadena);
  char x = 'A';

  x = tolower(x);

   strlwr(cadena);

    strupr(cadena2);

    puts(cadena2);



    puts(cadena);

   //strcpy(cadena2, cadena);
  //largo = strlen(cadena);

   //printf("Ingrese su nombre: ");
   //scanf("%s", cadena);
  // gets(cadena);



//printf("%d\n\n", largo);
  // printf("Usted se llama %s\n\n", cadena2);

 // puts("Hola mundo");







    return 0;
}























